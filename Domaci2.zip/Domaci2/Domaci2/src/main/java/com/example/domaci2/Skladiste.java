package com.example.domaci2;
public class Skladiste{
        private static int statId = 0;
        private int id=++statId;
        public int [] niz;
        private int ulaz;
        private int izlaz;
        private int stanje;
        private final int kapacitet;
        public int getStanje() {
            return stanje;
        }
        public int getId() {
            return id;
        }
        public int getK(){
            return kapacitet;
        }
        public Skladiste( int kapacitet ) {
            this.kapacitet = kapacitet;
            niz = new int[kapacitet];
        }
        public synchronized void Stavi (int element) throws InterruptedException{
            while(stanje == kapacitet) wait();
            niz[ulaz++] = element;
            stanje++;
            if(ulaz == kapacitet)ulaz = 0;
            notifyAll();
        }
        public synchronized int Uzmi() throws InterruptedException{
            while(stanje==0)wait();
            int element = niz[izlaz];
            niz[izlaz++]=0;
            stanje--;
            if(izlaz == kapacitet) izlaz=0;
            notifyAll();
            return element;
        }
    public synchronized void  stampajSkladiste()throws InterruptedException{
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.kapacitet; i++) {
            sb.append(i);
            sb.append(": ");
            sb.append( this.niz[i]);
            sb.append("\n");
        }
        System.out.println(sb);
    }
}

