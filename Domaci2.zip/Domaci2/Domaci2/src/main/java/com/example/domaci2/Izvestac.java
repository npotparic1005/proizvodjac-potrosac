package com.example.domaci2;

public class Izvestac extends Thread {
    private static int statId = 0;
    private int id;
    private Skladiste skladiste;

    public Izvestac(Skladiste skladiste) {
        this.skladiste = skladiste;
    }

    public void run() {
        try {
            while (!interrupted()) {

                Thread.sleep(10000);//na svakih 10s
                id= ++statId;
                System.out.println("Izveštaj o skladištu broj: " + id );
                /*    for(int i=0;i<this.skladiste.getK();i++){
                        System.out.println(i+":"+skladiste.niz[i]);
                }*/
                this.skladiste.stampajSkladiste();

            }
            //

        } catch (InterruptedException ex) {
            System.out.println("Izveštac " + id + " je završio sa radom");
        }
    }
}