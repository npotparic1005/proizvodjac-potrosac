package com.example.domaci2;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;

public class Main {
        public static void main(String[] args) {
            try{
                Skladiste skladiste = new Skladiste(5);
                Izvestac izvestac = new Izvestac(skladiste);

                Proizvodjac proizvodjac= new Proizvodjac(skladiste, 9000, 10000);
                Proizvodjac proizvodjac2= new Proizvodjac(skladiste, 9000, 10000);
                Proizvodjac proizvodjac3= new Proizvodjac(skladiste, 9000, 10000);
                Proizvodjac proizvodjac4= new Proizvodjac(skladiste, 9000, 10000);
                Proizvodjac proizvodjac5= new Proizvodjac(skladiste, 9000, 10000);
                Proizvodjac proizvodjac6= new Proizvodjac(skladiste, 9000, 10000);
                Proizvodjac proizvodjac7= new Proizvodjac(skladiste, 9000, 10000);
                Proizvodjac proizvodjac8= new Proizvodjac(skladiste, 9000, 10000);
                Proizvodjac proizvodjac9= new Proizvodjac(skladiste, 9000, 10000);
                Proizvodjac proizvodjac10= new Proizvodjac(skladiste, 9000, 10000);

                Potrosac potrosac = new Potrosac(skladiste, 15000, 20000);
                Potrosac potrosac2 = new Potrosac(skladiste, 15000, 20000);
                Potrosac potrosac3 = new Potrosac(skladiste, 15000, 20000);
                Potrosac potrosac4 = new Potrosac(skladiste, 15000, 20000);
                Potrosac potrosac5 = new Potrosac(skladiste, 15000, 20000);
                Potrosac potrosac6 = new Potrosac(skladiste, 15000, 20000);
                Potrosac potrosac7 = new Potrosac(skladiste, 15000, 20000);
                Potrosac potrosac8 = new Potrosac(skladiste, 15000, 20000);
                Potrosac potrosac9 = new Potrosac(skladiste, 15000, 20000);
                Potrosac potrosac10 = new Potrosac(skladiste, 15000, 20000);


                proizvodjac.start();
                proizvodjac2.start();
                proizvodjac3.start();
                proizvodjac4.start();
                proizvodjac5.start();
                proizvodjac6.start();
                proizvodjac7.start();
                proizvodjac8.start();
                proizvodjac9.start();
                proizvodjac10.start();

                potrosac.start();
                potrosac2.start();
                potrosac3.start();
                potrosac4.start();
                potrosac5.start();
                potrosac6.start();
                potrosac7.start();
                potrosac8.start();
                potrosac9.start();
                potrosac10.start();
                izvestac.start();


                sleep(60000);
                proizvodjac.interrupt();
                proizvodjac2.interrupt();
                proizvodjac3.interrupt();
                proizvodjac4.interrupt();
                proizvodjac5.interrupt();
                proizvodjac6.interrupt();
                proizvodjac7.interrupt();
                proizvodjac8.interrupt();
                proizvodjac9.interrupt();
                proizvodjac10.interrupt();

                potrosac.interrupt();
                potrosac2.interrupt();
                potrosac3.interrupt();
                potrosac4.interrupt();
                potrosac5.interrupt();
                potrosac6.interrupt();
                potrosac7.interrupt();
                potrosac8.interrupt();
                potrosac9.interrupt();
                potrosac10.interrupt();
                izvestac.interrupt();
            }catch (InterruptedException e){}






        }
}
